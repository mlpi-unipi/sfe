from scipy.optimize import differential_evolution
import pyNetLogo
import multiprocessing as mp
import sys
from datetime import datetime
from datetime import timedelta
import email, smtplib, ssl
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import email
import imaplib
import os
import sys
import numpy as np
import statistics as stat
import math

nome_script, arg1 = sys.argv

#### CONFIGURAZIONE ############################

algoritmo="sciadro"
maxTickNuber=1440 # numero massimo tick oltre il quale stoppare l'esecuzione --> 1440 tick == durata batteria UAV
netlogo_path='../netlogo-5.3.1-64' # path for Netlogo bridge
model_path='../Simulazione-'+algoritmo+'/SCD src.nlogo'
scenario = arg1
criterioStop = "percentageTgtsFound" 
simulation_number = 5 # number of simulations to execute for each parameters configuration 
numeroEsecuzioniDifferenziale = 1 #numero di simulazioni dell'intero algoritmo differenziale 
numeroWorker = 48+2 # 4*numero parametri da ottimizzare + 2 per sicurezza
tempoMassimoTraSimulazioni = timedelta(minutes=5) #margine massimo di tempo tra la conclusione di due simulazioni parallele
#ricordare di cambiare le mail per inviare i risultati a fine esecuzione!

################################################

#### CONFIGURAZIONE PER DE PARAMETERS TUNING ###

#mutation_strategies = ['rand1bin','best1bin']
mutation_strategies = ['rand1bin'] # EDIT PER ERRORE RETE -- DA CANCELLARE E RIPRISTINARE RIGA PRECEDENTE
#crossover_rates = np.arange(0.1, 1.0, 0.1) # CR in [0.1,0.9], step = 0.1
crossover_rates = np.arange(0.8, 1.0, 0.1) # EDIT PER ERRORE RETE -- DA CANCELLARE E RIPRISTINARE RIGA PRECEDENTE
scaling_factors = np.arange(0.4, 1.0, 0.1) # F  in [0.4,0.9], step = 0.1
print('MUTATION STRATEGIES: {}'.format(mutation_strategies))
print('CROSSOVER RATES: {}'.format(crossover_rates))
print('SCALING FACTORS: {}'.format(scaling_factors))

################################################

lock = mp.Lock()
m = mp.Manager()
manager = m.Namespace()
nomeFileLog = "log_"+algoritmo+"_"+scenario+"_"+datetime.now().strftime("%m-%d_%H-%M-%S")+".txt"
event=None
netlogo=None
manager.generazione = 1
manager.individuo = 0
individuiPerGenerazione = numeroWorker-2 #deve essere uguale al numero di individui per generazione!
manager.fitness = maxTickNuber
manager.fitnessMigliorIndividuo = maxTickNuber
manager.migliorIndividuoGenerazione = None
manager.migliorIndividuo = None
manager.conto = 0
manager.simulazione = 0
manager.fineUltimaSimulazione = datetime.now()
manager.nuovaGenerazione = True
manager.tempoScaduto = False
manager.maxTickNuber = maxTickNuber

#inizializzazione dei parametri
def inizializza():
    nomeFileLog = "log_"+algoritmo+"_"+scenario+"_"+datetime.now().strftime("%m-%d_%H-%M-%S")+".txt"
    manager.generazione = 1
    manager.individuo = 0
    manager.fitness = maxTickNuber
    manager.fitnessMigliorIndividuo = maxTickNuber
    manager.migliorIndividuoGenerazione = None
    manager.migliorIndividuo = None
    manager.conto = 0
    manager.simulazione = 0
    manager.fineUltimaSimulazione = datetime.now()
    manager.nuovaGenerazione = True
    manager.tempoScaduto = False
    manager.maxTickNuber = maxTickNuber

#Classe che contiene la configurazione dei parametri da ottimizzare
class Configuration():
    # class to organize Netlogo simulation parameters
    def __init__(self):
    # costants
        self.constants={
            'strategy?' : 3,
            'drone.radius': 0.2,
            'drone.speedMax': 8.5,
            'drone.cruisingSpeed': 2,
            'drone.acceleration': 2,
            'drone.deceleration': -2,
            'drone.velocityAngularMax': 2.6,
            'drone.accelerationAng': 7,
            'drone.decelerationAng': -7,
            'drone.endurance': 24,
            'sensing.radius': 2.5,
            'sensing.angle': 360,
            'rectangleBase': 5,     #sensingBase
            'rectangleHeight': 4,     #sensingHeight
            'drone.reachable.radius': 4,
            'drone.reachable.angle': 360,
            'drone.collision.vision': 6,
            'drone.sight.angleMax': 60,
            'drone.collision.gapAngle': 20
        }
    #configuration parameters
        self.parameters={
            'strategy?' : 3,
            'drone.radius': 0.2,
            'drone.speedMax': 8.5,
            'drone.cruisingSpeed': 2,
            'drone.acceleration': 2,
            'drone.deceleration': -2,
            'drone.velocityAngularMax': 2.6,
            'drone.accelerationAng': 7,
            'drone.decelerationAng': -7,
            'drone.endurance': 24,
            'sensing.radius': 2.5,
            'sensing.angle': 360,
            'rectangleBase': 5,     #sensingBase
            'rectangleHeight': 4,     #sensingHeight
            'drone.reachable.radius': 4,
            'drone.reachable.angle': 360,
            'drone.collision.vision': 6,
            'drone.sight.angleMax': 60,
            'drone.collision.gapAngle': 20,
            'mark.radiusTop': 8,
            'mark.radiusDown': 18,
            'track.evapRate': 0.16,
            'olfactoryHabituation': 22,
            'drone.flocking.angle': 42,
            'drone.flocking.wiggleVar': 14,
            'drone.flocking.radiusSeparate': 15,
            'drone.flocking.maxSeparateTurn': 33,
            'drone.flocking.radiusAlign': 19,
            'drone.flocking.maxAlignTurn': 33,
            'drone.flocking.radiusCohere': 21,
            'drone.flocking.maxCohereTurn': 24
        }
    
    #boundaries of parameters
        self.paramBoundaries={
            
            'mark.radiusTop': (1,13),
            'mark.radiusDown': (13,19),
            'track.evapRate': (0.01,0.1),
            'olfactoryHabituation': (1,10),
            'drone.flocking.angle': (15,45),
            'drone.flocking.wiggleVar': (5,15),
            'drone.flocking.radiusSeparate': (6,16),
            'drone.flocking.maxSeparateTurn': (30,45),
            'drone.flocking.radiusAlign': (16,22),
            'drone.flocking.maxAlignTurn': (30,45),
            'drone.flocking.radiusCohere': (18,26),
            'drone.flocking.maxCohereTurn': (15,30)
        }
    # print parameters and boundaries     
    def showParameters(self):
        for key,value in self.parameters.items():
            if key in self.paramBoundaries:
                bounds=self.paramBoundaries[key]

                print( key,' =',value,' | bounds= ',bounds)
            else:
                print( key,' =',value,' | bounds= const value')

    # create list for differential_evolution algorythm
    def createBoundsList(self):
        bounds=[]
        for key,value in self.paramBoundaries.items():
            bounds.append(value)
        return bounds

    # name passed as 'name'
    def addParameter(self,name,value,min_bounder,max_bounder):
        self.parameters[name]=value
        self.paramBoundaries[name]=(min_bounder,max_bounder)
    
    #remove parameter
    def removeParameter(self,name):
        del self.parameters[name]
        del self.paramBoundaries[name]
        print('removed ' + ' ' 
            + name 
            + ' : ' + str(self.parameters[name]) 
            + ', bounds = ' + str(self.paramBoundaries[name])
         )
    
    # set parameters value from a specified array
    # the order of values in the array must
    # be the same of Configuration.parameters
    def refreshConfiguration(self,x):
        count=0
        for key,value in self.paramBoundaries.items():
            self.parameters[key]=x[count]
            count+=1
        for key,value in self.constants.items():
            self.parameters[key]=self.constants[key]
        print('saved new configuration!')
#FINE-CLASSE


def get_body(email_message):
    for payload in email_message.get_payload():
        break
    return payload.get_payload()

#legge le mail in arrivo e termina l'esecuzione se il soggetto Ã¨ STOP
def readMailAndKill(server,uname,pwd):
    try:
        username = uname
        password = pwd
        mail = imaplib.IMAP4_SSL(server)
        mail.login(username, password)
        mail.select("inbox")
        result, data = mail.uid('search', None, '(UNSEEN)')
        inbox_item_list = data[0].split()
        most_recent = inbox_item_list[-1]
        result2, email_data = mail.uid('fetch', most_recent, '(RFC822)')
        raw_email = email_data[0][1].decode("UTF-8")
        email_message = email.message_from_string(raw_email)

        for payload in email_message.get_payload():
            if (email_message['Subject'] == "STOP"):
                chiudiSimulazione("INTERROTTA\n",'',0,0)
        mail.logout()
    except:
        pass

#per inviare una mail con i risultati a fine esecuzione
def invioMailLog(destinatario, log, soggetto):
    try:
        subject = soggetto
        body = "Simulazione: " + log
        sender_email = "ing.research.droni@gmail.com"
        receiver_email = destinatario
        password = "MailDroni"

        message = MIMEMultipart()
        message["From"] = sender_email
        message["To"] = receiver_email
        message["Subject"] = subject
        message["Bcc"] = receiver_email 


        message.attach(MIMEText(body, "plain"))
        filename = log 

        with open(filename, "rb") as attachment:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(attachment.read())

        encoders.encode_base64(part)

        part.add_header(
            "Content-Disposition",
            f"attachment; filename= {filename}",
        )

        message.attach(part)
        text = message.as_string()

        context = ssl.create_default_context()
        with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, text)
    except:
        print("Errore di invio mail")


def init_worker():
    global netlogo,netlogo_path,model_path

    #open dialog with netlogo
    netlogo=pyNetLogo.NetLogoLink(gui='false',
                                netlogo_home=netlogo_path,
                                netlogo_version='5')
    netlogo.load_model(model_path)
    #set scenario
    netlogo.command('set selectScenario "'+scenario+'"')
    
    #manager.conto +=1
    #print ("processo creato n: "+str(manager.conto))

def eseguiSimulazione(x):
        lock.acquire()
        manager.simulazione +=1
        numero = manager.simulazione
        print ("simulazione iniziata n: "+str(manager.simulazione))
        lock.release()
        
        #Il valore delle variabili globali viene letto da ogni worker, ma non possono essere modificati se non in locale al worker
        global netlogo,parameters_config,netlogo_path,model_path,simulation_number,event,individuiPerGenerazione,simulation_number

        save_results=[]
        i=0
        tickOverflow=0

        if netlogo is None:
            #open dialog with netlogo
            netlogo=pyNetLogo.NetLogoLink(gui='false',
                                netlogo_home=netlogo_path,
                                netlogo_version='5')
            netlogo.load_model(model_path)
            #set scenario
            netlogo.command('set selectScenario "'+scenario+'"')
        try:
            while(i<simulation_number and tickOverflow != 1):
                readMailAndKill("imap.gmail.com", "ing.research.droni@gmail.com", "MailDroni")
                #print("LOG ("+ datetime.now().strftime("%m-%d %H:%M:%S") +"): [ "+mp.current_process().name+" ] simulazione_"+str(i+1)+" avviata")
                cmd="setup read-from-string substring date-and-time 9 12"
                netlogo.command(cmd)

                #set parameters
                count=0
                # used for visual debug
                #optimized_params={}
                
                for key,value in parameters_config.paramBoundaries.items():
                    cmd="set " + key + " " + str(x[count])

                    netlogo.command(cmd)
                    #used for debug
                    #optimized_params[key]=x[count]

                    count += 1

            
                #initial target found
                target_found=netlogo.report(criterioStop)
                tick_number=0
           

                #continue simulation until stop condition
                #netlogo.repeat_command("go",100) #meno di 100 tick sono fisicamente impossibili in ogni scenario 
                while (target_found<=95): #<--------------------------------------------
                    if(tick_number > manager.maxTickNuber or ((datetime.now() > manager.fineUltimaSimulazione + tempoMassimoTraSimulazioni or manager.tempoScaduto == True) and manager.nuovaGenerazione == False and manager.individuo > individuiPerGenerazione/2)):
                        tick_number=manager.maxTickNuber
                        tickOverflow = 1
                        #print("OPT ("+ datetime.now().strftime("%m-%d %H:%M:%S") +"): [ "+mp.current_process().name+" ] overflow simulazione_"+str(i+1))  
                        if(datetime.now() > manager.fineUltimaSimulazione + tempoMassimoTraSimulazioni and manager.nuovaGenerazione == False and manager.individuo > individuiPerGenerazione/2):
                            manager.tempoScaduto = True
                        break
                    netlogo.repeat_command("go",1) #si potrebbe mettere a 5 anche se dÃÂ  un margine di errore per velocizzare
                    target_found=netlogo.report(criterioStop)
                    tick_number=netlogo.report('ticks')

                #print("LOG ("+ datetime.now().strftime("%m-%d %H:%M:%S") +"): [ "+mp.current_process().name+" ] ticks simulazione_"+str(i+1)+" = "+str(tick_number))
                # append simulation results for AVG 
                save_results.append(tick_number)
                i+=1
        
            #sum_avg=0
            #for val in save_results:
            #    sum_avg+=val

            #find AVG
            if(tickOverflow != 1):
              tick_number=round(stat.mean(save_results),2)
            else:
              tick_number= maxTickNuber

        except Exception as e:
            print("si e' verificato un errore nell'esecuzione del worker " + mp.current_process().name)
            print(e)
            
            tick_number=maxTickNuber

        #modifica per confidence interval
        sd = 0
        ci = 0
        if (len(save_results)>=2):
            sd = stat.stdev(save_results)
            ci = round(1.96 * (sd / math.sqrt(len(save_results))),2)

        lock.acquire()
        
        manager.fineUltimaSimulazione = datetime.now()
        manager.nuovaGenerazione = False

        manager.individuo += 1 

        if(manager.fitness >= tick_number):
            manager.fitness = tick_number
            manager.migliorIndividuoGenerazione = x

        if(manager.fitnessMigliorIndividuo >= tick_number):
            manager.fitnessMigliorIndividuo = tick_number
            manager.migliorIndividuo = x

        fileLog = open(nomeFileLog, "a+")
        fileLog.write("IND: "+str(manager.individuo)+" GEN: "+str(manager.generazione)+" ("+ datetime.now().strftime("%m-%d %H:%M:%S") +"): [ "+mp.current_process().name+" ] RESULTS: " + str(save_results) + " - AVG TICKS: " +str(tick_number) + " +- " + str(ci) + "\n")
        if(manager.individuo >= individuiPerGenerazione):
            manager.generazione = manager.generazione + 1
            manager.individuo = 0
            fileLog.write ( "--- FINE GENERAZIONE "+str(manager.generazione-1)+ " f(x)= "+str(manager.fitness)+"\n Miglior individuo generazione:\n "+str(manager.migliorIndividuoGenerazione)+"\n")
            fileLog.write ("Miglior risultato = "+ str(manager.fitnessMigliorIndividuo) + "\nMiglior Individuo:\n" + str(manager.migliorIndividuo)+"\n")
            manager.fitness = maxTickNuber
            fileLog.close()
            #invioMailLog("domenico.mnc@gmail.com", nomeFileLog, "Cambio Generazione")
            manager.nuovaGenerazione = True
            manager.tempoScaduto = False
            manager.maxTickNuber = manager.fitnessMigliorIndividuo*2
        else:
            fileLog.close()

        lock.release()

        #netlogo.kill_workspace()
        #event.set()

        lock.acquire()
        manager.simulazione -=1
        print ("simulazioni ancora in corso: "+str(manager.simulazione))
        lock.release()

        return tick_number

def chiudiSimulazione(risultati,ms,f,cr):
        #sys.stdout.close()
        #sys.stdout = sys.__stdout__
        
        fileLog = open(nomeFileLog, "a+")
        fileLog.write('\nValori parametri ottimi:\n')
        fileLog.write(str(risultati))
        if(risultati == "INTERROTTA\n"):
             pool.terminate()
        else:
             pool.close()
       
        #fileTemporaneo = open("tmp.txt","r")
        #fileLog.write(fileTemporaneo.read())
        fileLog.write('\n\n--- PARAMETRI UTILIZZATI: \nMUTATION STRATEGY = {}; \nF = {}; \nCR = {} \n---\n'.format(ms,f,cr))
        fileLog.write ("\n--- FINE ESECUZIONE "+ datetime.now().strftime("%m-%d %H:%M:%S") +" ---\n")
        fileLog.close()
        #fileTemporaneo.close()
        
        
        #invio mail log
        if(f > 0.85):
            invioMailLog("domenico.mnc@gmail.com", nomeFileLog, 'SFE-RR1 -- Parametri: STRATEGIA = {}; F = {}; CR = {}'.format(ms,f,cr))

        if(risultati == "INTERROTTA\n"):
             sys.exit()
     
if __name__ == '__main__':
    
    for ms in mutation_strategies:
        for cr in crossover_rates:
            for f in scaling_factors:
                i = 0
                while(i < numeroEsecuzioniDifferenziale):

                    inizializza()    

                    fileLog = open(nomeFileLog, "a+")
                    fileLog.write ("--- INIZIO ESECUZIONE "+ datetime.now().strftime("%m-%d %H:%M:%S") +" ---\n")
                    fileLog.close()
                    
                    
                    # parameter configuration initialize
                    parameters_config=Configuration()
                    #create array of only parameters boundaries
                    bounds=parameters_config.createBoundsList()
                    #modifyModel('../sciadro-3.1')

                    pool=mp.Pool(processes=numeroWorker,initializer=init_worker,initargs=())
                    print('starting optimization...\n')
                    #sys.stdout = open("tmp.txt", "w+")
                    try:            
                        result=differential_evolution(eseguiSimulazione,
                                                bounds,
                                                disp=True,
                                                init='latinhypercube',
                                                polish=False,
                                                atol=0,
                                                tol=0,
                                                mutation=f,
                                                recombination=cr,
                                                strategy=ms,
                                                maxiter=40,
                                                popsize=4,
                                                updating='deferred',
                                                workers=pool.map)    
                    except KeyboardInterrupt:
                        print('closing pool...')
                        chiudiSimulazione("INTERROTTA\n",'',0,0)

                    chiudiSimulazione(result,ms,f,cr)
                    i += 1 
